# SafeHand
Android camera application to snap picture with overlay. These overlays are mainly based on the awareness against global pandemic Corona.

## Demo image
![Demo image](https://github.com/rahathossain690/SafeHand/blob/master/nakshi2.jpg?raw=true)
![Demo image](https://github.com/rahathossain690/SafeHand/blob/master/nakshi.jpg?raw=true)
[Picture taken in landscape for no reason.]

