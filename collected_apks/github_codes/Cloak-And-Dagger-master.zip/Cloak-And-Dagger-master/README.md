# CloakandDagger
An overlay attack example

This app is a project for my cybersecurity class and is not intended to be distributed or used in the real world. 
The design follows the concept created by Yanick Fratantonio, Chenxiong Qian, Simon Pak Ho Chung, and Wenke Lee. 
More information on their discovery can be found at http://cloak-and-dagger.org/. This app only explores obtaining the 
SYSTEM_ALERT_WINDOW permission and creating a simple keylogger overlay once granted permission. 

Note: This app was tested on a Nexus 5X emulator using API 24. Testing on other devices or API's will likely require 
      modifying the layoutParams x and y dimensions.
