Camera-Overlay-Android
======================

Overlay Image in Camera Android and take picture

Custom Surface View and overlay image, and show and save the picture fo folder photoAR SDcard

![ScreenShot](https://raw.github.com/SeptiyanAndika/Camera-Overlay-Android/master/result.jpg)

