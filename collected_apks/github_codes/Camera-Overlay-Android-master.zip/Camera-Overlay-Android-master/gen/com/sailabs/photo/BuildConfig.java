/** Automatically generated file. DO NOT MODIFY */
package com.sailabs.photo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}